import time, pygame, sys, random
pygame.init
width, height = 600, 600
backgroundColor = 255, 255, 255
pygame.display.set_caption("simulateur_feu")

screen = pygame.display.set_mode((width, height))

brown = pygame.image.load("brown.png")
brownRect = brown.get_rect()

green = pygame.image.load("green.png")
greenRect = green.get_rect()

lime = pygame.image.load("lime.png")
limeRect = lime.get_rect()

blue = pygame.image.load("blue.png")
blueRect = blue.get_rect()

grey = pygame.image.load("grey.png")
greyRect = grey.get_rect()

iterations = 100
Liste_Cases = []

def Creer_Grille (iterations):
    for i in range (iterations):
        Liste_Cases.append([])

def Creer_Case (iterations_2, biome_case, intensite_case, etat_case):
    dictionary = {"Biome" : biome_case, "Intensite du feu" : intensite_case, "etat" : etat_case}
    Liste_Cases[iterations_2].append(dictionary)
    
def Choix_biome():
    Choix = random.randint(0,4)
    return Choix

def Remplir_Grille_Intitiale(iterations):
    Creer_Grille(iterations)
    for j in range(iterations):
        for i in range(iterations):
            Creer_Case (j,Choix_biome(), 0, "c trkl")



# 0 "plaine", 1 "foret", 2 "plantation", 3 "eau", 4 "maison"

Remplir_Grille_Intitiale(iterations)

def affichage(iterations):
    brown = pygame.image.load("brown.png")
    brownRect = brown.get_rect()

    green = pygame.image.load("green.png")
    greenRect = green.get_rect()

    lime = pygame.image.load("lime.png")
    limeRect = lime.get_rect()

    blue = pygame.image.load("blue.png")
    blueRect = blue.get_rect()

    grey = pygame.image.load("grey.png")
    greyRect = grey.get_rect()
    
    liste_Cases_Images = []
    for i in range (iterations):
        liste_Cases_Images.append([])
        for j in range (iterations):
            liste_Cases_Images[i].append([])
            if Liste_Cases[i][j]["Biome"] == 0:
                liste_Cases_Images[i][j].append(brown)
                liste_Cases_Images[i][j].append(brownRect)
            if Liste_Cases[i][j]["Biome"] == 1:
                liste_Cases_Images[i][j].append(green)
                liste_Cases_Images[i][j].append(greenRect)
            if Liste_Cases[i][j]["Biome"] == 2:
                liste_Cases_Images[i][j].append(lime)
                liste_Cases_Images[i][j].append(limeRect)
            if Liste_Cases[i][j]["Biome"] == 3:
                liste_Cases_Images[i][j].append(blue)
                liste_Cases_Images[i][j].append(blueRect)
            if Liste_Cases[i][j]["Biome"] == 4:
                liste_Cases_Images[i][j].append(grey)
                liste_Cases_Images[i][j].append(greyRect)
            liste_Cases_Images[i][j][1] = liste_Cases_Images[i][j][1].move(j*6,i*6)
            screen.blit(liste_Cases_Images[i][j][0],liste_Cases_Images[i][j][1])

while True:
    screen.fill (backgroundColor)
    Liste_Cases = []
    Remplir_Grille_Intitiale(iterations)
    affichage(iterations)
    pygame.display.flip()
    time.sleep(1)