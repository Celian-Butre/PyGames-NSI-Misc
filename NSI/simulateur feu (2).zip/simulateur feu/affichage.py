import time, pygame, sys, random
pygame.init
width, height = 1100, 600
backgroundColor = 255, 255, 255
pygame.display.set_caption("simulateur_feu")

screen = pygame.display.set_mode((width, height))

brown = pygame.image.load("brown.png")
brownRect = brown.get_rect()

green = pygame.image.load("green.png")
greenRect = green.get_rect()

lime = pygame.image.load("lime.png")
limeRect = lime.get_rect()

blue = pygame.image.load("blue.png")
blueRect = blue.get_rect()

grey = pygame.image.load("grey.png")
greyRect = grey.get_rect()

wait10 = 0
iterations = 100
Liste_Cases = []
isPaused = True
readyToPauseOrPlay = False

import random
import copy
Liste_Cases = []

def Creer_Grille (iterations):
    for i in range (iterations):
        Liste_Cases.append([])

def Creer_Case (iterations_2, biome_case, intensite_case, etat_case):
    dictionary = {"Biome" : biome_case, "Intensite du feu" : intensite_case, "etat" : etat_case}
    Liste_Cases[iterations_2].append(dictionary)

def forestPosition (i, j, cptForet, forestStorage):
    if forestStorage[i][j] == 0:
        cptForet += 1
    forestStorage[i][j] = 1
    return cptForet

def seedToForest(Choixbiome, iterations):
    cptForet = 0
    for i in range (7):
        Choixbiome[random.randint(0,iterations-1)][random.randint(0,iterations-1)]= 1
        cptForet += 1

    while cptForet < ((35/100)*iterations*iterations):
        forestStorage = copy.deepcopy(Choixbiome)
        for i in range (iterations):
            for j in range (iterations):
                if Choixbiome[i][j] == 1:
                    if (i >0):
                        cptForet = forestPosition(i-1,j, cptForet,forestStorage)
                    if (i < iterations-1):
                        cptForet = forestPosition(i+1,j, cptForet,forestStorage)
                    if (j >0):
                        cptForet = forestPosition(i,j-1, cptForet,forestStorage)
                    if (j < iterations-1):
                        cptForet = forestPosition(i,j+1, cptForet,forestStorage)
                    if ( (i >0 and i < iterations-1) and (j >0 and j < iterations-1) ):
                        listePositionsDiagonales = [[i-1,j-1],[i+1,j-1],[i-1,j+1],[i+1,j+1]]
                        for i in range(4):
                            foretDiagonale = random.randint(0,10)
                            if (foretDiagonale >= 6 and forestStorage[listePositionsDiagonales[i][0]][listePositionsDiagonales[i][1]] == 0):
                                cptForet += 1
                                forestStorage[listePositionsDiagonales[i][0]][listePositionsDiagonales[i][1]] = 1
                                
        Choixbiome = copy.deepcopy(forestStorage)
    return Choixbiome
def lakePosition (i, j, cptLac, LakeStorage):
    if LakeStorage[i][j] == 0:
        cptLac += 1
    LakeStorage[i][j] = 2
    return cptLac

def dropToLake(Choixbiome, iterations):
    cptLac = 0
    for i in range (4):
        randomNumber1 = random.randint(0,iterations-1)
        randomNumber2 = random.randint(0,iterations-1)
        try:
            assert(Choixbiome[randomNumber1][randomNumber2] != 1)
        except AssertionError:
            randomNumber1 = random.randint(0,iterations-1)
            randomNumber2 = random.randint(0,iterations-1)
        Choixbiome[randomNumber1][randomNumber2] = 2
        cptLac += 1

    while cptLac < ((25/100)*iterations*iterations):
        lakeStorage = copy.deepcopy(Choixbiome)
        for i in range (iterations):
            for j in range (iterations):
                if Choixbiome[i][j] == 2:
                    if (i >0 and lakeStorage[i-1][j] != 1):
                        cptLac = lakePosition(i-1,j, cptLac,lakeStorage)
                    if (i < iterations-1 and lakeStorage[i+1][j] != 1):
                        cptLac = lakePosition(i+1,j, cptLac,lakeStorage)
                    if (j >0 and lakeStorage[i][j-1] != 1):
                        cptLac = lakePosition(i,j-1, cptLac,lakeStorage)
                    if (j < iterations-1 and lakeStorage[i][j+1] != 1):
                        cptLac = lakePosition(i,j+1, cptLac,lakeStorage)
                    if ( (i >0 and i < iterations-1) and (j >0 and j < iterations-1) ):
                        listePositionsDiagonales = [[i-1,j-1],[i+1,j-1],[i-1,j+1],[i+1,j+1]]
                        for i in range(4):
                            lacDiagonale = random.randint(0,10)
                            if (lacDiagonale >= 6 and lakeStorage[listePositionsDiagonales[i][0]][listePositionsDiagonales[i][1]] == 0):
                                cptLac += 1
                                lakeStorage[listePositionsDiagonales[i][0]][listePositionsDiagonales[i][1]] = 2
        Choixbiome = copy.deepcopy(lakeStorage)
    return Choixbiome


def Choixbiome(iterations):
    Choixbiome=[] 
    for i in range (iterations):
        Choixbiome.append([])
        for j in range (iterations):
            Choixbiome[i].append(0)
    Choixbiome = seedToForest(Choixbiome, iterations)
    choixbiome = dropToLake(Choixbiome, iterations)
    return Choixbiome

def Remplir_Grille_Intitiale(iterations):
    Creer_Grille(iterations)
    choix_Biome = Choixbiome(iterations)
    for j in range(iterations):
        for i in range(iterations):
            Creer_Case (j,choix_Biome[i][j], 0, "c trkl")




# 0 "plaine", 1 "foret", 2 "plantation", 3 "eau", 4 "maison"

def defaultAffichage():
    global isPaused, readyToPauseOrPlay
    black = pygame.image.load("black.png")
    blackRect = black.get_rect()
    
    black2 = black
    black2Rect = blackRect
    
    forward = pygame.image.load("forward.png")
    forwardRect = forward.get_rect()
    
    backward = pygame.image.load("backward.png")
    backwardRect = backward.get_rect()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    keys = pygame.key.get_pressed()

    mouse = pygame.mouse.get_pressed()
    mousepos = pygame.mouse.get_pos()
    if mouse[0] == 1:
        mousepressed = True
    else:
        mousepressed = False
        
    if mousepressed and (((mousepos[0] - 937.5) * (mousepos[0] - 937.5)) + ((mousepos[1] - 137.5) * (mousepos[1] - 137.5))) <= (37.5*37.5):
        readyToPauseOrPlay = True
    
    if (((mousepos[0] - 937.5) * (mousepos[0] - 937.5)) + ((mousepos[1] - 137.5) * (mousepos[1] - 137.5))) > (37.5*37.5):
        readyToPauseOrPlay = False
        
    if mousepressed  == False and (((mousepos[0] - 937.5) * (mousepos[0] - 937.5)) + ((mousepos[1] - 137.5) * (mousepos[1] - 137.5))) <= (37.5*37.5) and readyToPauseOrPlay == True:
        readyToPauseOrPlay = False
        isPaused = not isPaused
    

    if isPaused == False:
        pauseOrPlay = pygame.image.load("pause.png")
    else:
        pauseOrPlay = pygame.image.load("play.png")
    
    pauseOrPlayRect = pauseOrPlay.get_rect()
    
    blackRect = blackRect.move(225, 0)
    black2Rect = black2Rect.move(850, 0)
    
    backwardRect = backwardRect.move(25, 100)
    forwardRect = forwardRect.move(125, 100)
    
    pauseOrPlayRect = pauseOrPlayRect.move(900, 100)
    
    screen.blit(black, blackRect)
    screen.blit(black2, black2Rect)
    
    screen.blit(forward, forwardRect)
    screen.blit(backward, backwardRect)
    
    screen.blit(pauseOrPlay, pauseOrPlayRect)

def affichage(iterations):
    brown = pygame.image.load("brown.png")
    brownRect = brown.get_rect()

    green = pygame.image.load("green.png")
    greenRect = green.get_rect()

    lime = pygame.image.load("lime.png")
    limeRect = lime.get_rect()

    blue = pygame.image.load("blue.png")
    blueRect = blue.get_rect()

    grey = pygame.image.load("grey.png")
    greyRect = grey.get_rect()
    
    liste_Cases_Images = []
    for i in range (iterations):
        liste_Cases_Images.append([])
        for j in range (iterations):
            liste_Cases_Images[i].append([])
            if Liste_Cases[i][j]["Biome"] == 0:
                liste_Cases_Images[i][j].append(brown)
                liste_Cases_Images[i][j].append(brownRect)
            if Liste_Cases[i][j]["Biome"] == 1:
                liste_Cases_Images[i][j].append(green)
                liste_Cases_Images[i][j].append(greenRect)
            if Liste_Cases[i][j]["Biome"] == 2:
                liste_Cases_Images[i][j].append(lime)
                liste_Cases_Images[i][j].append(limeRect)
            if Liste_Cases[i][j]["Biome"] == 3:
                liste_Cases_Images[i][j].append(blue)
                liste_Cases_Images[i][j].append(blueRect)
            if Liste_Cases[i][j]["Biome"] == 4:
                liste_Cases_Images[i][j].append(grey)
                liste_Cases_Images[i][j].append(greyRect)
            liste_Cases_Images[i][j][1] = liste_Cases_Images[i][j][1].move(250+j*6,i*6)
            screen.blit(liste_Cases_Images[i][j][0],liste_Cases_Images[i][j][1])

Remplir_Grille_Intitiale(iterations)
while True:
    print (1)
    screen.fill (backgroundColor)
    defaultAffichage()
    if wait10 >= 10:
        wait10 = 0
    #if wait10 == 0 and isPaused == False:
        #Liste_Cases = []
        #Remplir_Grille_Intitiale(iterations)
    affichage(iterations)
    pygame.display.flip()
    time.sleep(1)
    wait10 += 1