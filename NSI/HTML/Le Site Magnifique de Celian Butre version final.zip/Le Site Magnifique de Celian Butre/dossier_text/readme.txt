- Célian Butré + le site qui boost l'égo

- Fichier Principal: Ma_Page_Fantastique.html

- Arborescence:

website

|--- dossier_text
    
    |--- readme.txt

|--- dossier_java

    |--- java2.js
    
    |--- Java_site_magnifique.js
    
    |--- indexjava.js

|--- dossier_image
    
    |--- Une_Photo_Génial_de_Célian.jpg
    
    |--- Censure.jpg

|--- dossier_html

    |--- dossier_tableau
        
        |--- Mon_Surprenant_Tableau.html
        
    |--- Mon_Génialissime_QCM.html

    |--- Ma_Page_Fantastique.html

    |--- Les_Liens_Ravissants_De_Célian_Butré.html

    |--- la_page_de_téléportation.html

|--- dossier_css
    
    |--- style.css